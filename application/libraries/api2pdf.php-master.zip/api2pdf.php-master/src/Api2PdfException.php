<?php

namespace Api2Pdf;

use Exception;

class Api2PdfException extends Exception
{
}
